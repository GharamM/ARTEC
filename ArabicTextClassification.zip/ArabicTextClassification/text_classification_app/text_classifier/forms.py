from django import forms
from django.core.validators import FileExtensionValidator


class FileUploadForm(forms.Form):
    files = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), validators=[
                            FileExtensionValidator(allowed_extensions=['txt'])])
