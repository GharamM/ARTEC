from django.apps import AppConfig


class TextClassifierConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "text_classifier"
